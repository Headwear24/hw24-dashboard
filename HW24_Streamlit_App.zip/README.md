# HW24 Sales Dashboard Generator

A Streamlit web app that generates all 6 regional HTML sales dashboards
from the raw data export. Upload the file, set the week, download the dashboards.

---

## One-time setup (15 minutes)

### Step 1 — Create a free GitHub account
1. Go to https://github.com and sign up (free)
2. Click **New repository**
3. Name it: `hw24-dashboard`
4. Set to **Private**
5. Click **Create repository**

### Step 2 — Upload these files to GitHub
In your new repository, click **uploading an existing file** and upload:
- `app.py`
- `dashboard_generator.py`
- `requirements.txt`

Click **Commit changes**.

### Step 3 — Deploy on Streamlit Cloud
1. Go to https://share.streamlit.io and sign in with your GitHub account
2. Click **New app**
3. Select your `hw24-dashboard` repository
4. Main file path: `app.py`
5. Click **Deploy**

Streamlit will install everything and give you a link like:
`https://yourname-hw24-dashboard-app-xxxxx.streamlit.app`

### Step 4 — Share the link
Send that link to your team. That's it — they open it in any browser,
upload the file, and download the dashboards. No install required.

---

## Daily use (for your team)

1. Open the link
2. Set **Month**, **Week**, and **Days elapsed** in the left panel
3. Upload the `.xlsx` data file
4. Click **Generate all 6 dashboards**
5. Download individually or as a ZIP

---

## Updating the app (when you need layout changes)

1. Come to Claude and describe the change
2. Claude updates `dashboard_generator.py`
3. Download the updated file
4. Go to your GitHub repository
5. Click on `dashboard_generator.py` → Edit → paste new code → Commit
6. Streamlit Cloud detects the change and redeploys in ~2 minutes
7. Everyone using the link gets the new version automatically

---

## Troubleshooting

**"Sheet not found" error**
The Excel file must contain a sheet named exactly `AFS 26 Data`

**App runs slowly**
First load takes ~30 seconds (Streamlit wakes up the server).
Subsequent runs are faster.

**"Module not found" error**
Make sure all 3 files (app.py, dashboard_generator.py, requirements.txt)
are uploaded to GitHub.
